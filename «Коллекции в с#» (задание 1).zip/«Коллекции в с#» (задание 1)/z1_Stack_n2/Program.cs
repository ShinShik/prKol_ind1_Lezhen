﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z1_Stack_n2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string glas = "уеыаоэяию";
            Stack<char> Mystack = new Stack<char>();
            StreamReader sr = File.OpenText("txt.txt");
            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                foreach (char c in line)
                {
                    var glassnue = from g in glas
                                   where g == c
                                   select g;
                    foreach (char g in glassnue)
                    {
                        Mystack.Push(g);
                    }
                }
            }
            foreach (char c in Mystack)
            {
                Console.Write(c);
            }
            Console.ReadKey();
        }
    }
}
