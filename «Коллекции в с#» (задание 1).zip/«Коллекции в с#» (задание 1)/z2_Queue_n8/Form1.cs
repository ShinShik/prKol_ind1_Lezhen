﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace z2_Queue_n8
{
    public partial class Form1 : Form
    {
        Queue<Department> MyQueue = new Queue<Department>();
        public Form1()
        {
            InitializeComponent();
            StreamReader sr = File.OpenText("txt.txt");
            while (!sr.EndOfStream)
            {
                string[] line = sr.ReadLine().Split();
                MyQueue.Enqueue(new Department(line[0], line[1], line[2], line[3], int.Parse(line[4]), double.Parse(line[5])));
            }            
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var years_30 = from dep in MyQueue
                           where dep.Years < 30
                           select dep;
            var years_others = from dep in MyQueue
                               where dep.Years >= 30
                               select dep;
            foreach (var d in years_30) 
            {
                string department = $"{d.Surname} {d.Name} {d.Patronymic} {d.Sex} {d.Years} {d.Money}";
                listBox1.Items.Add(department);
            }
            foreach (var d in years_others)
            {
                string department = $"{d.Surname} {d.Name} {d.Patronymic} {d.Sex} {d.Years} {d.Money}";
                listBox1.Items.Add(department);
            }
        }
    }
}
