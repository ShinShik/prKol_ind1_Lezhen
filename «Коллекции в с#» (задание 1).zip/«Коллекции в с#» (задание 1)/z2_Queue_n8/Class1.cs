﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace z2_Queue_n8
{
    internal class Department
    {
        public string Surname { get; set; }
        public string Name { get; set; }        
        public string Patronymic { get; set; }
        public string Sex { get; set; }
        public int Years { get; set; }
        public double Money { get; set; }

        public Department(string surname, string name, string patronymic, string sex, int years, double money)
        {            
            this.Surname = surname;
            this.Name = name;
            this.Patronymic = patronymic;
            this.Sex = sex;
            this.Years = years;
            this.Money = money;
        }
        public Department()
        {

        }
    }
}
